﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr16_4zad
{
    public partial class Form1 : Form
    {
        Hashtable colec = new Hashtable();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.ColumnCount = 3;
            dataGridView1.Columns[0].Name="НОМЕР ДИСКА";
            dataGridView1.Columns[1].Name="ИСПОЛНИТЕЛЬ";
            dataGridView1.Columns[2].Name = "ПЕСНЯ";

        }
        private void Updatel()
        {
            dataGridView1.Rows.Clear();
            foreach (DictionaryEntry it in colec)
            {
                string nomer = it.Key.ToString();
                ArrayList name = (ArrayList)it.Value;
                string[] row = { nomer, name[0].ToString(), name[1].ToString() };
                dataGridView1.Rows.Add(row);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = dataGridView1.SelectedCells[0].RowIndex;

            if (selectedRowIndex >= 0)
            {
                string num = dataGridView1[0, selectedRowIndex].Value.ToString();
                colec.Remove(num);
                Updatel();
            }
            else MessageBox.Show("выберите строку для удаления", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            string nomer = Convert.ToString(numericUpDown1.Value);
            string ispol = textBox1.Text;
            string name = textBox2.Text;

            if (nomer != "" && ispol != "" && name != "")
            {
                if (!colec.ContainsKey(nomer))
                {
                    colec.Add(nomer, new ArrayList());
                    ArrayList pesni = (ArrayList)colec[nomer];
                    pesni.Add(ispol);
                    pesni.Add(name);
                    Updatel();
                }
                else MessageBox.Show("диск с таким номером уже есть", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                

            }
            else MessageBox.Show("заполните все строки!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

    
          

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != "")
            {
                string singer = textBox3.Text;
                var ss = from DictionaryEntry it in colec
                         where ((ArrayList)it.Value)[0].ToString() == singer
                         select new
                         {
                             nomer = it.Key,
                             ispol = ((ArrayList)it.Value)[0],
                             pesnya = ((ArrayList)it.Value)[1]

                         };
                foreach (var s in ss)
                {
                    string isp = (string)s.ispol, num = (string)s.nomer, pesnya = (string)s.pesnya;
                    string rez = isp + " - " + pesnya + " лежит на диске " + num;
                    MessageBox.Show(rez);
                }

            }
            else MessageBox.Show("введите исполнителя", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }


        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
